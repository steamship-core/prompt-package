import json
import boto3

# Get AWS Lambda Client
lambda_client = boto3.client('lambda')

def lambda_handler(event, context):

    domain_prefix = None
    proxy_path = None
    verb = None

    if "requestContext" in event:
        if "domainPrefix" in event["requestContext"]:
            domain_prefix = event["requestContext"]["domainPrefix"]

    if "pathParameters" in event:
        if "proxyPath" in event["pathParameters"]:
            proxy_path = event["pathParameters"]["proxyPath"]

    if "requestContext" in event:
        if "http" in event["requestContext"]:
            if "method" in event["requestContext"]["http"]:
                verb = event["requestContext"]["http"]["method"]

    app_name = domain_prefix

    invocation = {
        "app_id": None,
        "instance_id": None,
        "verb": verb,
        "method": proxy_path,
        "arguments": json.loads(event.get("body", b"{}"))
    }
    
    arn = 'arn:aws:lambda:us-east-2:072191725249:function:{}'.format(app_name)
    
    try:
        # run the child lambda
        response = lambda_client.invoke(
            FunctionName=arn,
            InvocationType='RequestResponse',
            Payload=json.dumps(invocation)
        )
        
        print("response", response)
        
        # return the result
        return {
            'statusCode': 200,
            'body': response['Payload'].read(),
        }
    except Exception as e:
        return str(e)

class AcrModels:
  ASSEMBLY_DEFAULT = "acr_assembly_default"

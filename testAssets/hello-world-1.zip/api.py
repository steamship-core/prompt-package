from typing import Dict
from nludb_app import App, Response
from nludb_app.app import post
from nludb_app.lambda_handler import create_lambda_handler

class HelloWorld(App):
  @post('hello')
  def learn(self, name: str = "Person"):
    return Response(
      json={
        'greeting': 'Hello, {}'.format(name)
      }
    )

handler = create_lambda_handler(HelloWorld())

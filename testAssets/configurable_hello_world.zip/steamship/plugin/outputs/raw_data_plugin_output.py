class RawDataPluginOutput:
    pass

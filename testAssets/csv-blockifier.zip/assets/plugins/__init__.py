"""Collection of plugins built using the Steamship framework."""

from enum import Enum


class Vendor(str, Enum):
    OneAI = "one-ai"

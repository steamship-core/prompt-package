"""Collection of utility functions."""
